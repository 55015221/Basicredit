-- phpMyAdmin SQL Dump
-- version 3.3.4
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 11 月 16 日 10:58
-- 服务器版本: 5.1.69
-- PHP 版本: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `dbh249016`
--

-- --------------------------------------------------------

--
-- 表的结构 `basic_article`
--

CREATE TABLE IF NOT EXISTS `basic_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- 转存表中的数据 `basic_article`
--

INSERT INTO `basic_article` (`id`, `parent_id`, `title`, `content`, `createtime`) VALUES
(1, 5, '公司介绍', '<div style="text-indent:2em;">\r\n	<p>\r\n		<span style="line-height:2;font-size:14px;">深圳市典信科技有限公司成立于2009年，‘典信’寓意为信用管理的集大成者。公司自创始之初便专注于企业往来账款管理与信用管理方面的研究，并以此为基础，致力于帮助企业调整往来业务处理方法、改善企业的往来管理状态、全面提升企业的信用管理能力，进而增加企业资源利用效率、促进与上下游企业及金融机构的信息沟通、降低企业成本、提高企业利润。</span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:12px;line-height:2;"><span style="font-size:14px;">典信公司成立之初便集聚了一批在公司财务管理、金融、IT等各方面优秀人才，尤其是在往来账款电子化与信用管理方面，更是拥有行业内最顶尖的人才队伍。公司有信心有能力帮助客</span><span style="font-size:14px;">户实现相关业务及管理的大幅提升，并让客户感受到我们的专业热心的服务，享受管理进步与技术进步带来的巨大利益。</span></span> \r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-size:14px;">我们的产品，以电子化和信息化为手段，以提升客户信</span><span style="line-height:2;font-size:14px;">用管理水平为目标，通过构建强大的IT体系平台，形成标准的信息交互机制，从而实现对往来账款业务的精准管理。</span> \r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-size:14px;">从短期来看，可以很好地帮客户解决(往来账款管理)对账的问题；从长远来看，可以帮助客户建立起自己的独立的、完整的信用业务管理体系，从而为客户在多个方面带来巨大的经济利益。</span> \r\n	</p>\r\n</div>', '2012-11-16 15:29:33'),
(2, 6, '企业文化', '<div>\r\n	<p>\r\n		<span style="font-weight:bold;font-size:10.5pt;font-family:宋体;line-height:2.5;">公司精神</span><span style="font-weight:bold;font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5pt;font-family:宋体;line-height:2.5;">使命&nbsp;专注&nbsp;信赖&nbsp;</span><span style="font-weight:bold;font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-weight:bold;font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-weight:bold;font-size:10.5pt;font-family:宋体;line-height:2.5;">公司使命&nbsp;&nbsp;</span><span style="font-weight:bold;font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"><span style="line-height:2.5;">构建诚信、高效、安全的交易环境</span><span style="line-height:2.5;">,</span><span style="line-height:2.5;">让信任从此简单</span></span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-weight:bold;font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-weight:bold;font-size:10.5pt;font-family:宋体;line-height:2.5;">公司目标</span><span style="font-weight:bold;font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5pt;font-family:宋体;line-height:2.5;">立志成为全球首屈一指的信用环境供应商</span><span style="font-size:10.5000pt;font-family:''Calibri'';"></span> \r\n	</p>\r\n</div>', '2012-11-16 15:29:33'),
(10, 8, '招贤纳士', '<dl class="list-none metlist" style="margin-top:0px;margin-right:0px;margin-bottom:15px;margin-left:0px;padding-top:0px;padding-right:5px;padding-bottom:15px;padding-left:5px;list-style-type:none;list-style-position:initial;list-style-image:initial;color:#333333;font-family:''Microsoft YaHei'', Tahoma, Verdana, Simsun;line-height:21px;white-space:normal;-webkit-text-size-adjust:none;background-color:#FFFFFF;">\r\n	<dt style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:10px;font-size:16px;font-weight:bold;border-bottom-width:1px;border-bottom-style:dotted;border-bottom-color:#CCCCCC;">\r\n		<a href="http://demo.metinfo.cn/job/job4.html" title="Web前端开发人员" target="_self" style="color:#333333;text-decoration:none;">Web前端开发人员</a> \r\n	</dt>\r\n	<dd class="list " style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:5px;padding-left:0px;">\r\n		<div class="mis" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:10px;">\r\n			<span style="margin-right:15px;color:#999999;">发布日期：2012-07-16</span><span style="margin-right:15px;color:#999999;">工作地点：长沙市</span><span style="margin-right:15px;color:#999999;">招聘人数：10</span> \r\n		</div>\r\n		<div class="editor" style="line-height:2;padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;">\r\n			<div>\r\n				<strong><span style="font-size:14px;">主要工作内容：</span></strong>负责企业网站管理系统前台模板功能设计、用户体验提升和Web界面技术优化。\r\n			</div>\r\n			<div>\r\n				<strong><span style="font-size:14px;">岗位要求：</span></strong> \r\n			</div>\r\n			<ol style="padding-left:25px;padding-top:0px;padding-right:0px;padding-bottom:0px;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;">\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					熟悉JavaScript、Ajax、JQuery等前端开发脚本技能；\r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					精通HTML/XHTML、CSS，能够快速手写CSS代码，熟悉页面架构和布局。\r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					熟悉Web网站以及Web应用的可用性及用户分析方法，深入理解产品流程、用户体验和用户需求，对提升用户体验有一定经验及造诣。\r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					对Web技术发展有强烈兴趣，有良好的学习能力和强烈的进取心，愿意同公司共同发展。\r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					能跟踪最新的WEB前端设计、懂PHP基本语言者优先。\r\n				</li>\r\n			</ol>\r\n		</div>\r\n		<div class="dtail" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:10px;border-top-width:1px;border-top-style:dotted;border-top-color:#CCCCCC;">\r\n			<span style="margin-right:20px;"><span style="color:#1c57c4;">在线</span><span style="color:#1c57c4;">应聘</span></span><span style="margin-right:20px;"><span style="color:#1c57c4;">查</span><span style="color:#1c57c4;">看详细</span></span> \r\n		</div>\r\n	</dd>\r\n</dl>\r\n<dl class="list-none metlist" style="margin-top:0px;margin-right:0px;margin-bottom:15px;margin-left:0px;padding-top:0px;padding-right:5px;padding-bottom:15px;padding-left:5px;list-style-type:none;list-style-position:initial;list-style-image:initial;color:#333333;font-family:''Microsoft YaHei'', Tahoma, Verdana, Simsun;line-height:21px;white-space:normal;-webkit-text-size-adjust:none;background-color:#FFFFFF;">\r\n	<dt style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:10px;font-size:16px;font-weight:bold;border-bottom-width:1px;border-bottom-style:dotted;border-bottom-color:#CCCCCC;">\r\n		<a href="http://demo.metinfo.cn/job/job5.html" title="电子商务专员" target="_self" style="color:#333333;text-decoration:none;">电子商务专员</a> \r\n	</dt>\r\n	<dd class="list " style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:5px;padding-left:0px;">\r\n		<div class="mis" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:10px;">\r\n			<span style="margin-right:15px;color:#999999;">发布日期：2012-07-16</span><span style="margin-right:15px;color:#999999;">工作地点：长沙市</span><span style="margin-right:15px;color:#999999;">招聘人数：10</span> \r\n		</div>\r\n		<div class="editor" style="line-height:2;padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;">\r\n			<p style="margin-top:0px;margin-bottom:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n				<strong><span style="font-size:14px;">主要工作内容：</span></strong>负责企业网站管理系统在线销售工作，向客户提供迅速、准确、周到的服务。\r\n			</p>\r\n			<div>\r\n				<strong><span style="font-size:14px;">岗位要求：</span></strong> \r\n			</div>\r\n			<ol style="padding-left:25px;padding-top:0px;padding-right:0px;padding-bottom:0px;margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;">\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					<span style="font-size:14px;">熟悉互联网销售与推广；</span> \r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					<span style="font-size:14px;">能熟练操作网站管理系统后台，了解基本的建站知识；</span> \r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					<span style="font-size:14px;">能敏锐把握网站建设行业市场动向，善于把握客户心理；</span> \r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					<span style="font-size:14px;">沟通能力强，勤奋耐劳，办事认真严谨细致；</span> \r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					<span style="font-size:14px;">具有较强的学习能力，愿意同公司共同发展；</span> \r\n				</li>\r\n				<li style="margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;">\r\n					<span style="font-size:14px;">有网站建设相关产品工作经验者优先，电子商务、市场营销等相关专业优先。</span> \r\n				</li>\r\n			</ol>\r\n		</div>\r\n	</dd>\r\n</dl>', '2012-11-16 22:08:11'),
(11, 9, '电子往来账款管理系统', '<div style="text-align:center;">\r\n	<span style="line-height:1.5;font-family:宋体;font-size:10.5pt;font-weight:bold;">电子往来账款管理系统</span> \r\n</div>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:14px;">电子往来账款管理系统是由典信公司独立开发的管理应用系统，具有自主知识产权。本系统主要侧重于企业往来及相关业务，包括往来、授信、信用管理等业务，系统以其为主要管理对象和业务对象，应用全新的思路进行设计和开发，突破了传统管理软件的瓶颈，可以解决传统管理软件和管理方法在该领域内不能很好解决的诸多问题，实现了极大的进步，并可给使用该系统的客户带来巨大的利益。</span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:14px;"><br />\r\n</span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:''宋体'';font-size:14px;"></span>&nbsp;\r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:''宋体'';font-size:10.5pt;"></span><span style="font-family:''Calibri'';font-size:10.5pt;"><span style="font-family:''宋体'';font-size:10.5pt;"><img alt="" align="left" src="__PUBLIC__/Upload/wps_clip_image-9778.gif" width="260" height="354" /></span></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:''宋体'';font-size:10.5pt;font-weight:bold;"><br />\r\n</span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:''宋体'';font-size:10.5pt;font-weight:bold;">主要功能：</span><span style="font-family:''Calibri'';font-size:10.5pt;font-weight:bold;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">往来债权管理：包括对预付账款、应收账款、其他应收款、其他债权的管理以及催收管理、坏账管理、对账管理与相应的查询；</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">往来债务管理：包括对预收账款、应付账款、其他应付款、其他债务的管理以及支付结算、对账管理与债务查询；</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">授信管理：主要实现对向客户赊销授信的额度管理以及接受供应商的授信赊购的额度管理；</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">信用管理：重点实现信用调查与信用评价功能。</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;"><br />\r\n</span>\r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;"><br />\r\n</span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;"><br />\r\n</span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:宋体;"><span style="font-size:14px;line-height:28px;"><br />\r\n</span></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:''宋体'';font-size:10.5pt;font-weight:bold;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:宋体;"><span style="font-size:14px;line-height:21px;"><b> <img src="__PUBLIC__/Upload/pro.jpg" width="230" height="230" align="right" alt="" style="border-style:initial;border-color:initial;font-family:宋体;font-size:14px;font-weight:bold;line-height:21px;text-indent:28px;white-space:normal;" /><span style="font-family:宋体;font-size:14px;font-weight:bold;text-indent:28px;white-space:normal;line-height:28px;"></span><br class="Apple-interchange-newline" />\r\n</b></span></span><span style="font-family:宋体;font-size:10.5pt;font-weight:bold;text-indent:21pt;">主要价值：</span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:''Calibri'';font-size:10.5pt;font-weight:bold;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">实时登记与确认往来业务信息，并与业务对方保持一致；</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">减少或免除相关业务的录入工作；</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">系统保持业务数据实时更新，免除与业务对方定期或临时对账的工作；</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">实现在线催收业务；</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">实时掌握自己的信用指数信息，并可将其授权给业务对方查询；</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<p style="text-indent:21pt;">\r\n	<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">在经业务对方授权情况下，可实时了解掌握对方的信用指数信息。</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n</p>\r\n<span style="white-space:normal;"> \r\n<p style="text-indent:21pt;">\r\n	<span style="font-family:''宋体'';font-size:10.5pt;"></span> \r\n</p>\r\n</span>', '2012-11-17 20:51:52'),
(12, 10, '服务', '<div><br />\r\n	<p>\r\n		<img alt="" align="left" src="__PUBLIC__/Upload/01.png" width="229" height="137" />&nbsp;<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;font-weight:bold;">往来业务管理在线平台服务</span><span style="font-family:''Calibri'';font-size:10.5pt;font-weight:bold;"></span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">面向个人用户、中小企业和其他没有部署内部专业系统的用户，提供在线的往来业务管理平台服务。让所有有需要的用户，都能使用到专业的系统与服务。</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">该平台提供的功能或服务内容与企业内部专业系统保持一致，用户在使用该平台时，即能享受与专业平台一致的功能与服务，而可节约大量的软硬件投入成本，并且可以免除系统实施上线的繁重工作，登记认证后即可开始使用。</span>&nbsp;<span style="line-height:2;">&nbsp;</span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="font-family:''宋体'';font-size:10.5pt;"></span><span style="font-family:''Calibri'';font-size:10.5pt;"></span><span style="line-height:2;">&nbsp;</span> \r\n	</p>\r\n	<p style="text-align:left;">\r\n		<img alt="" align="right" src="__PUBLIC__/Upload/02.jpg" width="258" height="167" /><span style="font-family:''宋体'';font-size:12pt;"></span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="font-family:''Calibri'';font-size:10.5pt;"></span>\r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;font-weight:bold;">业务登记与交换服务</span><span style="font-family:''Calibri'';font-size:10.5pt;font-weight:bold;"></span> \r\n	</p>\r\n	<p style="text-indent:20.25pt;">\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">典信公司作为独立第三方，向客户提供往来账款及相关业务的登记服务，并负责将登记的业务向相关的当事人系统进行转发。基于典信公司独特的业务地位，为向客户提供多种增值业务，提升客户价值提供了良好的发展空间。</span> \r\n	</p>\r\n	<p style="text-indent:20.25pt;">\r\n		<span style="font-family:''宋体'';font-size:10.5pt;"></span><span style="line-height:2;">&nbsp;</span> \r\n	</p>\r\n	<p style="text-indent:20.25pt;">\r\n		<span style="font-family:''宋体'';font-size:10.5pt;"></span><span style="line-height:2;">&nbsp;</span> \r\n	</p>\r\n	<p style="text-indent:20.25pt;">\r\n		<span style="font-family:''宋体'';font-size:10.5pt;"></span><span style="line-height:2;">&nbsp;</span> \r\n	</p>\r\n	<p style="text-indent:20.25pt;">\r\n		<img alt="" align="left" src="__PUBLIC__/Upload/03.jpg" width="228" height="178" /> \r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;font-weight:bold;">用户认证服务</span><span style="font-family:''Calibri'';font-size:10.5pt;font-weight:bold;"></span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">典信公司下设独立的用户认证机构，负责对系统的所有用户进行进行身份认证，尽最大可能保证所有用户身份的真实性、合法性和有效性。同时，该服务可以为系统用户在与其他关系人用户建立经济关系、发生经济业务时，免除或减少大量的重复性的身份认定工作，提高用户业务安全性。</span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="font-family:''宋体'';font-size:10.5pt;"></span><span style="line-height:2;">&nbsp;</span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="font-family:''宋体'';font-size:10.5pt;"></span><span style="line-height:2;"></span>&nbsp;\r\n	</p>\r\n	<p style="text-align:left;">\r\n		<img alt="" align="right" src="__PUBLIC__/Upload/04.jpg" width="282" height="146" /> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="font-family:''Calibri'';font-size:10.5pt;"></span>\r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;font-weight:bold;">信用指数服务</span><span style="font-family:''Calibri'';font-size:10.5pt;font-weight:bold;"></span> \r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;典信公司建立一套专业的信用指数评价体系，基于用户业务数据，可以为用户提供各自的即时的用户信用指数。以供用户随时掌握自己的信用情况。</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">通过用户授权，用户自身的信用指数也可以向其他关系方提供，或是进行公开，以方便用户向合作方进行信用传递。</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="line-height:2;font-family:''宋体'';font-size:10.5pt;">同时，用户也可以要求对应的关系人用户向自己开放其信用指数，以便自己进行管理决策和业务监控。</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n	</p>\r\n</div>', '2012-11-17 21:03:39'),
(13, 15, '咨询与方案', '<div>\r\n	<p style="text-align:center;">\r\n		<img alt="" align="right" src="__PUBLIC__/Upload/05.jpg" width="237" height="149" /><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-family:''宋体'';font-size:14px;font-weight:bold;">往来账款管理咨询</span><span style="font-family:''Calibri'';font-size:10.5pt;font-weight:bold;"></span> \r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-family:''宋体'';font-size:14px;">&nbsp;&nbsp;&nbsp;&nbsp;基于典信公司丰富的管理经验以及强大的软件与服务体系，公司可以为客户提供有关往来账款管理的问题诊断、业务咨询、建议、培训、与解决方案提供。帮助客户解决往来管理中的有关问题，提升往来管理效率，提高往来管理效果，为客户整体业务发展提供支持。</span> \r\n	</p>\r\n	<p>\r\n		<span style="font-family:''宋体'';font-size:10.5pt;"></span>&nbsp;\r\n	</p>\r\n	<p>\r\n		<span style="font-family:''Calibri'';font-size:10.5pt;"></span>&nbsp;\r\n	</p>\r\n	<p style="text-align:left;">\r\n		<img alt="" align="left" src="__PUBLIC__/Upload/06.jpg" width="248" height="184" />&nbsp;\r\n	</p>\r\n	<p>\r\n		<span style="font-family:''Calibri'';font-size:10.5pt;"></span>\r\n	</p>\r\n	<p>\r\n		<span style="line-height:2;font-family:''宋体'';font-size:14px;font-weight:bold;">信用管理咨询</span><span style="font-family:''Calibri'';font-size:10.5pt;font-weight:bold;"></span> \r\n	</p>\r\n	<p style="text-indent:21pt;">\r\n		<span style="line-height:2;font-family:''宋体'';font-size:14px;">中国的信用环境状况不佳，如何应对这样的环境，如何在这一条件下制订与实施自己的信用策略，提高用户识别信用风险，提升自已的信用水平，发挥出自身信用价值，是经济组织特别是企业的重要工作。典信公司借助自身先进的信用管理理论以及强大的业务平台实力，协助客户提高自身的信用水平，使信用发挥其应有的作用；同时提高对合作方的信用识别与管理的能力，为企业长期健康发展保驾护航。</span><span style="font-family:''Calibri'';font-size:10.5pt;"></span> \r\n	</p>\r\n</div>', '2012-11-17 21:08:43'),
(14, 7, '联系我们', '<p>\r\n	<span style="font-size:10.5000pt;font-family:''宋体'';"><span style="line-height:2;">地址</span><span style="line-height:2;">:&nbsp;</span><span style="line-height:2;">深圳市宝安区</span><span style="line-height:2;">2</span><span style="line-height:2;">区龙井二路</span><span style="line-height:2;">62</span><span style="line-height:2;">号</span><span style="line-height:2;">6</span><span style="line-height:2;">楼</span></span><span style="font-size:10.5000pt;font-family:''Calibri'';"></span> \r\n</p>\r\n<p>\r\n	<span style="font-size:10.5000pt;font-family:''宋体'';"><span style="line-height:2;">电话</span><span style="line-height:2;">:&nbsp;0755-29964020</span></span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n</p>\r\n<p>\r\n	<span style="font-size:10.5000pt;font-family:''宋体'';"><span style="line-height:2;">手机</span><span style="line-height:2;">: 13928455967</span></span><span style="font-size:10.5000pt;font-family:''Calibri'';"></span> \r\n</p>\r\n<p>\r\n	<span style="font-size:10.5000pt;font-family:''宋体'';"><span style="line-height:2;">邮箱</span><span style="line-height:2;">: jeffyli@basicredit.com</span></span><span style="font-size:10.5000pt;font-family:''Calibri'';"></span> \r\n</p>\r\n<p>\r\n	<span style="font-size:10.5000pt;font-family:''宋体'';"><span style="line-height:2;">网址</span><span style="line-height:2;">:&nbsp;</span></span><span style="color:#0000FF;font-size:10pt;font-family:宋体;"><a href="http://www.basicredit.com/"><span style="line-height:2;color:#337FE5;">www.basicredit.com</span></a></span><span style="font-size:10.5000pt;font-family:''Calibri'';"></span> \r\n</p>', '2012-11-17 21:44:44'),
(15, 16, '组织架构', '暂无内容~', '2012-11-25 01:02:33');

-- --------------------------------------------------------

--
-- 表的结构 `basic_column`
--

CREATE TABLE IF NOT EXISTS `basic_column` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `path` varchar(200) NOT NULL,
  `show` tinyint(4) NOT NULL,
  `pic` varchar(200) NOT NULL,
  `action` varchar(200) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `action` (`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `basic_column`
--

INSERT INTO `basic_column` (`id`, `parent_id`, `name`, `path`, `show`, `pic`, `action`, `sort`) VALUES
(1, 0, '首页', '0', 1, '', 'index', 0),
(2, 0, '关于典信', '0', 1, '07.jpg', 'about', 1),
(3, 0, '招贤纳士', '0', 0, '', 'jobs', 4),
(4, 0, '产品与服务', '0', 1, '09.jpg', 'products', 2),
(5, 2, '公司介绍', '0,2', 1, '', '', 0),
(6, 2, '企业文化', '0,2', 1, '', '', 0),
(7, 13, '联系我们', '0,13', 1, '', '', 0),
(8, 3, '招贤纳士', '0,2', 1, '', '', 0),
(9, 4, '产品', '0,4', 1, '', '', 0),
(10, 4, '服务', '0,4', 1, '', '', 0),
(11, 12, '公司活动', '0,12', 1, '', '', 0),
(12, 0, '公司动态', '0', 1, '15.jpg', 'news', 3),
(13, 0, '联系我们', '0', 1, '14.jpg', 'connect', 5),
(14, 12, '行业动态', '0,12', 1, '', '', 0),
(15, 4, '咨询', '0,4', 1, '', '', 0),
(16, 2, '组织架构', '0,2', 1, '', '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `basic_config`
--

CREATE TABLE IF NOT EXISTS `basic_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `webname` varchar(200) NOT NULL,
  `keywords` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `copyright` varchar(200) NOT NULL,
  `licence` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `basic_config`
--

INSERT INTO `basic_config` (`id`, `webname`, `keywords`, `description`, `logo`, `copyright`, `licence`) VALUES
(1, '深圳市典信科技有限公司', '电子往来账款管理系统、财务管理、金融、IT', '公司自创始之初便专注于企业往来账款管理与信用管理方面的研究，并以此为基 础，致力于帮助企业调整往来业务处理方法、改善企业的往来管理状态、全面提升企业的信用管理能力，进而增加企业资源利用效率、促进与上下游企业及金融机构 的信息沟通、降低企业成本、提高企业利润。', '__PUBLIC__/Images/logo.jpg', 'copyright  &copy;  版权所有', '粤ICP备11086626号-2');

-- --------------------------------------------------------

--
-- 表的结构 `basic_slider`
--

CREATE TABLE IF NOT EXISTS `basic_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `intro` varchar(500) NOT NULL,
  `url` varchar(200) NOT NULL,
  `pic` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `basic_slider`
--

INSERT INTO `basic_slider` (`id`, `title`, `intro`, `url`, `pic`) VALUES
(1, '典信科技有限公司', '典信科技有限公司典信科技有限公司', '', '01.jpg'),
(2, '典信科技有限公司', '典信科技有限公司典信科技有限公司', '', '11.jpg'),
(4, '', '', '', '12.jpg'),
(5, '', '', '', '13.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `dianxin_article`
--

CREATE TABLE IF NOT EXISTS `dianxin_article` (
  `id` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `dianxin_article`
--

INSERT INTO `dianxin_article` (`id`, `mid`, `title`, `content`, `createtime`, `status`) VALUES
(0, 8, '公司介绍', '    深圳市典信科技有限公司成立于2009年，‘典信’寓意为信用管理的集大成者。公司自创始之初便专注于企业往来账款管理与信用管理方面的研究，并以此为基础，致力于帮助企业调整往来业务处理方法、改善企业的往来管理状态、全面提升企业的信用管理能力，进而增加企业资源利用效率、促进与上下游企业及金融机构的信息沟通、降低企业成本、提高企业利润。\r\n　　　　通过多年深入分析研究往来账款与信用管理的实际情况，结合现有的技术手段，公司创造性地提出往来账款电子化的理论，根据这一理论，公司开发出电子往来账款管理系统。该系统面向各类企业，能够成熟、快速、全面地解决现有往来账款管理与信用管理领域中存在的诸多主要问题，为企业带来重大价值。同时，公司将通过持续的技术和理论创新、积极实践，立志成为全球首屈一指的信用环境提供商，促进信用及信息化发展，造福社会大众。\r\n　　　　典信公司成立之初便集聚了一批在公司财务管理、金融、IT等各方面优秀人才，尤其是在往来账款电子化与信用管理方面，更是拥有行业内最顶尖的人才队伍。公司有信心有能力帮助客户实现相关业务及管理的大幅提升，并让客户感受到我们的专业热心的服务，享受管理进步与技术进步带来的巨大利益。\r\n　　　　\r\n　　　　我们的产品，以电子化和信息化为手段，以提升客户信用管理水平为目标，通过构建强大的IT体系平台，形成标准的信息交互机制，从而实现对往来账款业务的精准管理。\r\n　　　　从短期来看，可以很好地帮客户解决(往来账款管理)对账的问题；从长远来看，可以帮助客户建立起自己的独立的、完整的信用业务管理体系，从而为客户在多个方面带来巨大的衍生经济利益。\r\n　　　　（利益包括：提高销售收入和利润、减少坏账损失、降低成本、提高资金周转率、减少对外部融资的依赖；减轻管理人员工作强度、提高工作效率、提升管理价值，等等。）', '2012-10-16 15:26:36', 1),
(1, 9, '企业文化', '企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，企业文化，', '2012-10-16 15:27:50', 2),
(2, 2, 'asfdasda', 'asdadasdasdasdasd', '2012-10-21 00:13:07', 1),
(3, 10, '产品', '<div class="span9">\r\n    <h2>\r\n        云DNS\r\n    </h2>\r\n    <p>\r\n        DNSPod拥有全球最领先的云 DNS 集群技术。6年 DNS 领域专业研究，无数次紧急 DNS 故障处理，让我们更有信心提供最好的服务。\r\n    </p>\r\n</div>\r\n<div class="span7">\r\n    <img style="float:right;margin-left:-20px;" src="https://www.dnspod.cn/yantai/img/content/features/feature1.jpg" />\r\n</div>\r\n<section>\r\n</section><!--end of second row-->\r\n<section class="row primary iepp-section">\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span6">\r\n        <img style="float:left" src="https://www.dnspod.cn/yantai/img/content/features/feature2.jpg" />\r\n    </div>\r\n    <div class="span6">\r\n    </div>\r\n    <div class="span10">\r\n        <h2>\r\n            DNSPod DNS Attack Detector &amp; Protector\r\n        </h2>\r\n        <p>\r\n            DNSPod DNS Attack Detector可以在 6秒内发现域名解析攻击行为并自动学习攻击特征；通过DNSPod DNS Protector 进行攻击防护处理并完成抓包取证，让DNSPod的DNS解析更加稳定。\r\n        </p>\r\n    </div><!--end of second row-->\r\n</section>\r\n<section class="row primary iepp-section">\r\n    <div class="span10">\r\n        <h2>\r\n        </h2>\r\n        <h2>\r\n        </h2>\r\n        <h2>\r\n        </h2>\r\n        <h2>\r\n            D监控\r\n        </h2>\r\n        <p>\r\n            D监控程序使用超过20种独有的算法，一旦网站服务器失去响应，立刻切换到备用服务器上，主服务器恢复后，再自动切换回去。让网站平稳运行。\r\n        </p>\r\n    </div>\r\n    <div class="span6">\r\n        <img style="float:right" src="https://www.dnspod.cn/yantai/img/content/features/feature3.v2.jpg" />\r\n    </div>\r\n</section><!--end of second row-->\r\n<section class="row secondary iepp-section">\r\n    <div class="span2">\r\n        <div class="features-small-1">\r\n        </div>\r\n    </div>\r\n    <div class="span14">\r\n        <h4>\r\n            无限域名，无限记录\r\n        </h4>\r\n        <p>\r\n            我们认为，基本的域名解析功能是不应受到任何限制的。你可以将所有的域名放在DNSPod统一管理。我们允许添加所有类型的解析记录，包括A、CNAME、NS、MX、TXT、SRV、AAAA（IPv6）……，甚至还有免费的 URL 转发。\r\n        </p>\r\n    </div>\r\n</section><!--end of second row-->\r\n<section class="row secondary iepp-section">\r\n    <div class="span2">\r\n        <div class="features-small-2">\r\n        </div>\r\n    </div>\r\n    <div class="span14">\r\n        <h4>\r\n        </h4>\r\n        <h4>\r\n        </h4>\r\n        <h4>\r\n        </h4>\r\n        <h4>\r\n        </h4>\r\n        <h4>\r\n            实时生效\r\n        </h4>\r\n        <p>\r\n            DNSPod专有的DNS同步引擎，仅仅几秒就可以将 DNS 记录同步到DNSPod全国的云DNS集群，快如闪电。\r\n        </p>\r\n    </div>\r\n</section><!--end of second row-->\r\n<section class="row secondary iepp-section">\r\n    <div class="span2">\r\n        <div class="features-small-3">\r\n        </div>\r\n    </div>\r\n    <div class="span14">\r\n        <h4>\r\n            99.99% 稳定运行时间\r\n        </h4>\r\n        <p>\r\n            DNSPod采用分布式DNS服务器架构。一个节点发生故障，其他节点不会受到影响，请求自动分配到可用服务器，对网站完全透明。\r\n        </p>\r\n    </div>\r\n</section><!--end of second row-->\r\n<section class="row secondary iepp-section">\r\n    <div class="span2">\r\n        <div class="features-small-4">\r\n        </div>\r\n    </div>\r\n    <div class="span14">\r\n        <h4>\r\n            搜索引擎优化\r\n        </h4>\r\n        <p>\r\n            新站想被马上收录？想收录更多页面？DNSPod完成你的心愿！我们与百度、搜搜、搜狗有着深入密切的合作关系，是全球唯一一家与搜索引擎合作的DNS服务商。网站一旦开始使用 DNSPod，数据将会被准确迅速地推送到各个搜索引擎\r\n        </p>\r\n    </div>\r\n</section><!--end of second row-->\r\n<section style="margin-bottom:20px;" class="row primary iepp-section">\r\n    <div class="span16">\r\n        <h2>\r\n            7x24小时技术支持\r\n        </h2>\r\n        <p>\r\n            除了快如闪电的解析速度、稳定安全的解析服务，DNSPod还有“全面、专业、快速”的技术支持团队为你提供7x24小时技术和业务咨询服务，企业QQ、400电话、在线论坛，快速轻松解决所有问题。\r\n        </p>\r\n    </div>\r\n</section><!--end of second row-->\r\n<section class="row primary iepp-section">\r\n    <div class="span5">\r\n        <img style="margin-left:-30px;" src="https://www.dnspod.cn/yantai/img/content/features/feature5.jpg" />\r\n    </div>\r\n    <div class="span11">\r\n        <h2>\r\n            最细致的区域划分\r\n        </h2>\r\n        <p>\r\n            我们拥有最权威最精确的地址库，用来准确定位请求来源，为之分配最佳解析结果。电信？联通？移动？教育网？这些还不够，DNSPod能给你各个大洲、国家，全国各种线路、各个省份的细致区域划分。\r\n        </p>\r\n    </div>\r\n</section><!--end of second row-->\r\n<section class="row primary iepp-section">\r\n    <div class="span11">\r\n        <h2>\r\n            简单易用\r\n        </h2>\r\n        <p>\r\n            DNSPod的管理界面简单易用、操作方便，大量人性化设计，即使数千个域名的操作，也可以在几分钟内轻松完成。\r\n        </p>\r\n    </div>\r\n    <div class="span5">\r\n        <img style="margin-left:-20px;" src="https://www.dnspod.cn/yantai/img/content/features/feature6.jpg" />\r\n    </div>\r\n</section><!--end of second row-->\r\n<section class="row primary iepp-section">\r\n    <div class="span14">\r\n        <h2>\r\n            DNSPod 为什么免费\r\n        </h2>\r\n        <p>\r\n            DNSPod上线6年来，一直致力于带给更多人免费的优质DNS解析服务。我们设计高性能的DNS软件，用更少的资源满足更多的用户需求；我们从来没有，也永远不会对基本的DNS功能收费。DNSPod还有额外的套餐，以合理的价格提供了更好的服务，满足大中型网站和企业的需求。\r\n        </p>\r\n    </div>\r\n</section><!--end of second row-->\r\n<section class="row primary why_vip iepp-section">\r\n    <div class="row">\r\n        <h2>\r\n            为什么要选择 VIP 服务　　　\r\n        </h2>\r\n    </div>\r\n    <div class="row">\r\n        <div class="span7">\r\n            <h3>\r\n                专属服务器\r\n            </h3>\r\n            <p>\r\n                VIP用户拥有独立的 DNS 服务器集群，分布在全国数十个大中城市，并独享 100G 带宽，在每秒处理数亿次DNS请求的情况下，依然保持 5ms 的响应时间。\r\n            </p>\r\n        </div>\r\n        <div class="span7">\r\n            <h3>\r\n                7x24小时技术支持\r\n            </h3>\r\n            <p>\r\n                专属技术支持全年无休，7x24小时等待你的咨询，5分钟响应所有问题。\r\n            </p>\r\n        </div>\r\n    </div>\r\n</section>\r\n<p>\r\n     \r\n</p>', '2012-10-22 10:52:44', 1),
(4, 11, '服务', '<img src="__ROOT__/Uploads/1.png">', '2012-10-22 10:54:01', 1),
(5, 7, '联系我们', '<h5 style="text-align:center;line-height:24px;font-family:&#39;microsoft yahei&#39; , simhei;font-size:18px">\r\n    财运来（大连）海洋生物有限公司<br />\r\n    <span style="font-size:12px;font-weight:normal">CAIYUNLAI (DALIAN) MARINE BIOLOGICAL Co.,LTD.</span>\r\n</h5>\r\n<p>\r\n     \r\n</p>\r\n<p>\r\n    <strong><span style="font-size:20px"><span style="color:#b22222">全国服务热线：400 - 188 - 1727</span></span><br />\r\n        公司地址：中国 • 大连市甘井子区泉水K3区19号<br />\r\n        垂询热线：+86-411-39630062</strong>\r\n</p>\r\n<p>\r\n    <strong>图文传真：+86-411-39731080<br />\r\n        官方网址：www.dlcyl.com<br />\r\n        电子信箱：dlcyl@126.com<br />\r\n        合作专线：138 4116 1727、133 9000 3266</strong>\r\n</p>\r\n<p>\r\n     \r\n</p>\r\n<p>\r\n     \r\n</p>', '2012-10-22 11:18:14', 1),
(7, 2, '公司新闻1', '公司新闻1公司新闻1公司新闻1公司新闻1公司新闻1', '2012-10-27 17:29:11', 1),
(8, 2, '公司新闻2', '公司新闻2公司新闻2公司新闻2公司新闻2公司新闻2公司新闻2', '2012-10-27 17:29:11', 2),
(9, 2, '公司新闻3', '公司新闻3公司新闻3公司新闻3公司新闻3公司新闻3公司新闻3', '2012-10-27 17:29:50', 3),
(10, 2, '公司新闻4', '公司新闻4公司新闻4公司新闻4公司新闻4公司新闻4公司新闻4公司新闻4', '2012-10-27 17:29:50', 4),
(6, 6, '招贤纳士', '<p>\r\n    <span style="font-size:14px"><span style="font-size:16px"><strong>【<span style="display:none"> </span>职位名称】<span style="display:none"> </span><span style="font-family:lucida sans unicode, lucida grande, sans-serif"><span style="text-decoration:underline">资深创意文案师</span></span></strong></span>            <strong>招聘人数：2名</strong></span>\r\n</p>\r\n<p>\r\n    <strong><span style="font-size:14px">                                                                    薪资待遇：五险+ 住房公积金，月薪RMB5,000元起</span></strong>\r\n</p>\r\n<p>\r\n    <strong><span style="font-size:14px">岗位职责：</span></strong>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       1、品牌规划；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       2、产品概念类创意与推导撰写；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       3、广告创意与撰写；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       4、推广物料类文字撰写；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       5、公司实战案例撰写等。</span>\r\n</p>\r\n<p>\r\n    <strong><span style="font-size:14px">任职资格：</span></strong>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       1、德行兼备，具有团队合作意识；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       2、精品牌与广告专业，通营销；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       3、有丰富</span><span style="font-size:14px">的品牌与广告创意文字表现能力；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       4、有超强</span><span style="font-size:14px">的写作逻辑与文字处理能力；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       5、有三年</span><span style="font-size:14px">以上水产品或高端滋补品行业资深经验和相关知名案例作品者优先。</span>\r\n</p>\r\n<p>\r\n     \r\n</p>\r\n<p>\r\n     \r\n</p>\r\n<p>\r\n    <span style="font-size:14px"><span style="font-size:16px"><strong>【<span style="display:none"> </span>职位名称】<span style="display:none"> </span><span style="text-decoration:underline"><span style="font-family:lucida sans unicode, lucida grande, sans-serif">资深设计师</span></span></strong></span>                   <strong>招聘人数：2名</strong></span>\r\n</p>\r\n<p>\r\n    <strong><span style="font-size:14px">                                                                  薪资待遇：五险+ 住房公积金，月薪RMB5,000元起</span></strong>\r\n</p>\r\n<p>\r\n    <strong><span style="font-size:14px">岗位职责：</span></strong>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       1、企业CI系统的设计和建设；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       2、产品包装的设计和制作；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       3、专卖店/柜的设计和装修；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       4、各种媒介广告的设计和制作；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       5、各种宣传物料的设计和制作；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       6、公司网站的设计和制作。</span>\r\n</p>\r\n<p>\r\n    <strong><span style="font-size:14px">任职资格：</span></strong>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       1、德行兼备，具有团队合作意识；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       2、熟练使用相关设计软件，了解网站制作流程；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       3、熟悉各种包装、广宣用品的成本、制作及流程；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       4、较深的美术功底，较强的设计表现能力、沟通组织能力；</span>\r\n</p>\r\n<p>\r\n    <span style="font-size:14px">       5、有三年以上水产品或高端滋补品行业资深经验和相关知名案例作品者优先。</span>\r\n</p>\r\n<p>\r\n     \r\n</p>\r\n<p>\r\n     \r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px"><span style="font-size:16px"><strong>【<span style="display:none"> </span>职位名称】<span style="display:none"> </span><span style="text-decoration:underline">销售主管</span></strong></span>                 <strong>  招聘人数：5名</strong></span>\r\n</p>\r\n<p>\r\n    <strong><span style="font-size:14px">                                                              薪资待遇：五险一金 + 销售提成，月薪RMB2,000元起</span></strong>\r\n</p>\r\n<p style="text-align:left">\r\n    <strong><span style="font-size:14px">岗位职责：</span></strong>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       1、负责完成本区域销售任务；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       2、主动积极开发区域内的销售网点；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       3、及时了解客户情况，及时反馈市场信息；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       4、管理客户、拜访终端，建立良好客情关系；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       5、协调客户与公司的矛盾、纠纷，加强客情关系，搞好售后服务工作；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       6、完成上级交办的其他任务。</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <strong><span style="font-size:14px">任职资格：</span></strong>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       1、德行兼备，具有良好的沟通、协调能力、优秀的谈判技巧，有较强的客户服务意识；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       2、能适应较大的工作压力，思维活跃，善于创新；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       3、较好的工作责任心及团队合作精神，有上进心，自我约束能力强；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       4、熟练操作电脑，分析、解决问题能力强；</span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px">       5、大专以上学历，一年以上海产品或高端营养滋补品行业销售工作经验者。 </span>\r\n</p>\r\n<p style="text-align:left">\r\n     \r\n</p>\r\n<p style="text-align:left">\r\n     \r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:14px"><strong>【<span style="display:none"> </span>应聘方式】<span style="display:none"> </span></strong></span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:12px"><strong>          请符合以上条件要求的应聘者将个人相关简历通过以下方式发至本公司：</strong></span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:12px"><strong>                  1、传真方式：请将简历发传真至 0411-39731080，行政部李女士收</strong></span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:12px"><strong>                  2、电子邮件：请将简历发邮件至  <a href="mailto:dlcyl@126.com">dlcyl@126.com</a>，行政部李女士收</strong></span>\r\n</p>\r\n<p style="text-align:left">\r\n    <span style="font-size:12px"><strong>          </strong></span><span style="font-size:12px"><strong>简历经公司收阅后，合则约见；谢绝登门或电话咨询应聘</strong></span>\r\n</p>\r\n<h5 style="text-align:center;line-height:24px;font-family:&#39;microsoft yahei&#39;, simhei;font-size:18px">\r\n     \r\n</h5>', '2012-10-22 11:21:44', 1);

-- --------------------------------------------------------

--
-- 表的结构 `dianxin_config`
--

CREATE TABLE IF NOT EXISTS `dianxin_config` (
  `id` tinyint(4) NOT NULL,
  `sitename` varchar(30) NOT NULL DEFAULT '典信科技有限公司',
  `logopath` varchar(30) NOT NULL DEFAULT '__PUBLIC__/logo.png',
  `recordno` varchar(30) NOT NULL DEFAULT '粤ICP备12067307号-1',
  `adminname` varchar(15) NOT NULL DEFAULT 'admin',
  `adminpass` char(32) NOT NULL DEFAULT '21232f297a57a5a743894a0e4a801fc3',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `dianxin_config`
--

INSERT INTO `dianxin_config` (`id`, `sitename`, `logopath`, `recordno`, `adminname`, `adminpass`) VALUES
(1, '典信科技有限公司', '__PUBLIC__/Images/logo.png', '粤ICP备11086626号-2', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- 表的结构 `dianxin_menu`
--

CREATE TABLE IF NOT EXISTS `dianxin_menu` (
  `id` int(11) NOT NULL,
  `action` varchar(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `pid` int(11) NOT NULL,
  `isshow` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `dianxin_menu`
--

INSERT INTO `dianxin_menu` (`id`, `action`, `name`, `pid`, `isshow`) VALUES
(0, 'Index', '首页', 0, 1),
(1, 'About', '关于我们', 0, 1),
(2, 'News', '公司动态', 0, 1),
(3, 'Products', '产品与服务', 0, 1),
(4, 'Cases', '客户与案例', 0, 0),
(5, 'Business', '业务合作', 0, 0),
(6, 'Jobs', '招贤纳士', 0, 1),
(7, 'Contact', '联系我们', 0, 1),
(8, '', '公司介绍', 1, 1),
(9, '', '企业文化', 1, 1),
(10, '', '软件产品', 3, 1),
(11, '', '服务与支持', 3, 1),
(12, '', '咨询', 3, 1);

-- --------------------------------------------------------

--
-- 表的结构 `dianxin_news`
--

CREATE TABLE IF NOT EXISTS `dianxin_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `content` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `dianxin_news`
--


-- --------------------------------------------------------

--
-- 表的结构 `fy_article`
--

CREATE TABLE IF NOT EXISTS `fy_article` (
  `article_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_title` varchar(255) NOT NULL,
  `article_content` longtext NOT NULL,
  `class_id` int(11) NOT NULL,
  `article_summary` varchar(500) NOT NULL,
  `article_keywords` varchar(255) NOT NULL,
  `article_description` varchar(500) NOT NULL,
  `article_pic` varchar(255) NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT '0',
  `article_hits` int(11) NOT NULL DEFAULT '0',
  `article_using` tinyint(4) NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='文章表' AUTO_INCREMENT=20 ;

--
-- 转存表中的数据 `fy_article`
--

INSERT INTO `fy_article` (`article_id`, `article_title`, `article_content`, `class_id`, `article_summary`, `article_keywords`, `article_description`, `article_pic`, `article_order`, `article_hits`, `article_using`, `create_time`) VALUES
(1, '公司介绍', '公司介绍<p style="text-indent:2em;">	<span style="line-height:2;">深圳市典信科技有限公司成立于2009年，‘典信’寓意为信用管理的集大成者。公司自创始之初便专注于企业往来账款管理与信用管理方面的研究，并以此为基础，致力于帮助企业调整往来业务处理方法、改善企业的往来管理状态、全面提升企业的信用管理能力，进而增加企业资源利用效率、促进与上下游企业及金融机构的信息沟通、降低企业成本、提高企业利润。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">通过多年深入分析研究往来账款与信用管理的实际情况，结合现有的技术手段，公司创造性地提出往来账款电子化的理论，根据这一理论，公司开发出电子往来账款管理系统。该系统面向各类企业，能够成熟、快速、全面地解决现有往来账款管理与信用管理领域中存在的诸多主要问题，为企业带来重大价值。同时，公司将通过持续的技术和理论创新、积极实践，立志成为全球首屈一指的信用环境提供商，促进信用及信息化发展，造福社会大众。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">典信公司成立之初便集聚了一批在公司财务管理、金融、IT等各方面优秀人才，尤其是在往来账款电子化与信用管理方面，更是拥有行业内最顶尖的人才队伍。公司有信心有能力帮助客户实现相关业务及管理的大幅提升，并让客户感受到我们的专业热心的服务，享受管理进步与技术进步带来的巨大利益。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">我们的产品，以电子化和信息化为手段，以提升客户信用管理水平为目标，通过构建强大的IT体系平台，形成标准的信息交互机制，从而实现对往来账款业务的精准管理。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">从短期来看，可以很好地帮客户解决(往来账款管理)对账的问题；从长远来看，可以帮助客户建立起自己的独立的、完整的信用业务管理体系，从而为客户在多个方面带来巨大的衍生经济利益。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">（利益包括：提高销售收入和利润、减少坏账损失、降低成本、提高资金周转率、减少对外部融资的依赖；减轻管理人员工作强度、提高工作效率、提升管理价值，等等。）</span> </p><p style="text-indent:2em;">	<br /></p>', 3, '', '', '', '0', 0, 0, 1, '0000-00-00 00:00:00'),
(2, '企业文化', '企业文化<p style="text-indent:2em;">	<span style="line-height:2;">深圳市典信科技有限公司成立于2009年，‘典信’寓意为信用管理的集大成者。公司自创始之初便专注于企业往来账款管理与信用管理方面的研究，并以此为基础，致力于帮助企业调整往来业务处理方法、改善企业的往来管理状态、全面提升企业的信用管理能力，进而增加企业资源利用效率、促进与上下游企业及金融机构的信息沟通、降低企业成本、提高企业利润。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">通过多年深入分析研究往来账款与信用管理的实际情况，结合现有的技术手段，公司创造性地提出往来账款电子化的理论，根据这一理论，公司开发出电子往来账款管理系统。该系统面向各类企业，能够成熟、快速、全面地解决现有往来账款管理与信用管理领域中存在的诸多主要问题，为企业带来重大价值。同时，公司将通过持续的技术和理论创新、积极实践，立志成为全球首屈一指的信用环境提供商，促进信用及信息化发展，造福社会大众。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">典信公司成立之初便集聚了一批在公司财务管理、金融、IT等各方面优秀人才，尤其是在往来账款电子化与信用管理方面，更是拥有行业内最顶尖的人才队伍。公司有信心有能力帮助客户实现相关业务及管理的大幅提升，并让客户感受到我们的专业热心的服务，享受管理进步与技术进步带来的巨大利益。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">我们的产品，以电子化和信息化为手段，以提升客户信用管理水平为目标，通过构建强大的IT体系平台，形成标准的信息交互机制，从而实现对往来账款业务的精准管理。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">从短期来看，可以很好地帮客户解决(往来账款管理)对账的问题；从长远来看，可以帮助客户建立起自己的独立的、完整的信用业务管理体系，从而为客户在多个方面带来巨大的衍生经济利益。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">（利益包括：提高销售收入和利润、减少坏账损失、降低成本、提高资金周转率、减少对外部融资的依赖；减轻管理人员工作强度、提高工作效率、提升管理价值，等等。）</span> </p><p style="text-indent:2em;">	<br /></p>', 4, '', '', '', '0', 0, 0, 1, '0000-00-00 00:00:00'),
(3, '联系我们', '<p>\n	一、航班到达：\n进入航站楼以后，您可参照航站楼内到达旅客的引导标识前往行李提取大厅。&nbsp;\n</p>\n<p>\n	二、检验检疫：\n请您填写健康申报单，交检验检疫部门查验。&nbsp;\n</p>\n<p>\n<pre class="prettyprint lang-php">&lt;?php\n\nclass ClassModel extends RelationModel {\n\n    protected $_link = array(\n        ''Article'' =&gt; array(\n            ''mapping_type'' =&gt; HAS_MANY,\n            ''mapping_name'' =&gt; ''Article'',\n            ''class_name'' =&gt; ''Article'',\n            ''foreign_key'' =&gt; ''class_id'',\n        ),\n        ''Picture'' =&gt; array(\n            ''mapping_type'' =&gt; BELONGS_TO,\n            ''mapping_name'' =&gt; ''Picture'',\n            ''class_name'' =&gt; ''Picture'',\n            ''foreign_key'' =&gt; ''picture_id'',\n            ''as_fields'' =&gt; ''picture_path,picture_thumb'',\n        ),\n    );\n\n    /**\n     * 获取页面内容\n     */\n    public function getIndexData($topid, &amp;$cid) {\n        $path = $this-&gt;getPath($topid);\n        $cid = $cid? : $path[0][''_child''][0][''class_id''];\n        $data = D(''Class'')-&gt;relation(true)-&gt;getDetail(array(''class_id'' =&gt; $cid));\n        return array(''path'' =&gt; $path, ''data'' =&gt; $data);\n    }\n\n    public function getList($where, $order = null, $limit = null) {\n        $where[''class_using''] = 1;\n        //empty($order) &amp;&amp; $order = array(''class_id'' =&gt; ''ASC'');\n        empty($order) &amp;&amp; $order = array("CONCAT(`class_path`,''-'',`class_id`)" =&gt; ''ASC'');\n        $result = $this-&gt;field(true)\n                -&gt;where($where)\n                -&gt;order($order)\n                -&gt;limit($limit)\n                -&gt;select();\n        return $result;\n    }\n\n    public function getDetail($where) {\n        $result = $this-&gt;field(true)\n                -&gt;where($where)\n                -&gt;find();\n        return $result;\n    }\n\n    /**\n     * 获取树形结构的列表\n     * @param int $cid 顶级栏目的ID\n     */\n    public function getPath($cid) {\n        $data = $this-&gt;allChild($cid);\n        return list_to_tree($data, ''class_id'', ''class_pid'');\n    }\n\n    public function allChild($cid) {\n        $where[''class_pid''] = array(''eq'', $cid);\n        $where[''class_path''] = array(''like'', ''0-'' . $cid . ''-%'');\n        $where[''class_id''] = array(''eq'', $cid);\n        $where[''_logic''] = ''or'';\n        $map[''_complex''] = $where;\n        $data = $this-&gt;getList($map);\n        return $data;\n    }\n\n    public function parsePath($args, $isTree = true) {\n        $data = array();\n        if (is_array($args)) {\n            $class = $this-&gt;getList($args);\n            if (count($class) &gt; 1) {\n                foreach ($class as $key =&gt; $value) {\n			$data[] = $this-&gt;allChild($value[''class_id'']);\n			$merge[] = ''$data["''.$key.''"]'';\n                }\n		eval(''$list = array_merge(''.implode('','',$merge).'');'');\n                //todo 这里需要修改 将未知个数的数组合并起来\n                //$list = array_merge($data[0], $data[1], $data[2], $data[3]);\n                return $isTree ? list_to_tree($list, ''class_id'', ''class_pid'') : $list;\n            } else {\n                return $this-&gt;parsePath($class[0][''class_id''], $isTree);\n            }\n        } else {\n            return $isTree ? $this-&gt;getPath($args) : $this-&gt;allChild($args);\n        }\n    }\n\n    /**\n     * 面包屑\n     */\n    public function getCrumbs($path) {\n        $path = ''1'' . strstr($path, ''-'');\n        $ids = join('','', explode(''-'', $path));\n        $where[''class_id''] = array(''in'', $ids);\n        $result = $this-&gt;getList($where);\n        return $result;\n    }\n\n}\n</pre>\n</p>\n<p>\n	三、边防检查：\n外国旅客入境须持有效的护照证件、入境签证，并将填好的入境登记卡连同护照证件、签证一并交边防检查站查验。\n中国旅客凭有效护照证件入境。&nbsp;\n</p>\n<p>\n	四、提取行李：\n行李提取厅位于一层，其入口处设有行李转盘显示屏，您可根据航班号查知您的托运行李所在的转盘。请在相应转盘提取行李，核对行李牌，避免行李错取。如出现行李运输不正常事故（如行李少收、破损等），请到航空公司行李查询柜台咨询。\n中转旅客（除南航澳洲航线外），尽管您的行李已挂至最终目的站，但敬请您提取行李，办理海关手续后，到中转柜台重新托运行李。（行李在广州必须办理出关手续）&nbsp;\n</p>\n<p>\n	五、海关检查：\n如果您携带有向海关申报的物品，须填写《中华人民共和国海关进出境旅客行李物品申报单》，选择“申报通道”（又称“红色通道”）通关；如果没有，无须填写《申报单》，选择“无申报通道”（又称“绿色通道”）通关。&nbsp;\n</p>\n<p>\n	六、离开机场：\n提取行李后您将通过A1安检口离开国际到达厅，在那里您可与亲友会面，或到酒店咨询柜台及问讯柜台进行咨询。可选择机场巴士或出租车离开机场。\n</p>', 5, '', '', '', '0', 0, 0, 1, '0000-00-00 00:00:00'),
(4, '企业文化', '<p style="text-indent:2em;">	<span style="line-height:2;">深圳市典信科技有限公司成立于2009年，‘典信’寓意为信用管理的集大成者。公司自创始之初便专注于企业往来账款管理与信用管理方面的研究，并以此为基础，致力于帮助企业调整往来业务处理方法、改善企业的往来管理状态、全面提升企业的信用管理能力，进而增加企业资源利用效率、促进与上下游企业及金融机构的信息沟通、降低企业成本、提高企业利润。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">通过多年深入分析研究往来账款与信用管理的实际情况，结合现有的技术手段，公司创造性地提出往来账款电子化的理论，根据这一理论，公司开发出电子往来账款管理系统。该系统面向各类企业，能够成熟、快速、全面地解决现有往来账款管理与信用管理领域中存在的诸多主要问题，为企业带来重大价值。同时，公司将通过持续的技术和理论创新、积极实践，立志成为全球首屈一指的信用环境提供商，促进信用及信息化发展，造福社会大众。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">典信公司成立之初便集聚了一批在公司财务管理、金融、IT等各方面优秀人才，尤其是在往来账款电子化与信用管理方面，更是拥有行业内最顶尖的人才队伍。公司有信心有能力帮助客户实现相关业务及管理的大幅提升，并让客户感受到我们的专业热心的服务，享受管理进步与技术进步带来的巨大利益。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">我们的产品，以电子化和信息化为手段，以提升客户信用管理水平为目标，通过构建强大的IT体系平台，形成标准的信息交互机制，从而实现对往来账款业务的精准管理。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">从短期来看，可以很好地帮客户解决(往来账款管理)对账的问题；从长远来看，可以帮助客户建立起自己的独立的、完整的信用业务管理体系，从而为客户在多个方面带来巨大的衍生经济利益。</span> </p><p style="text-indent:2em;">	<span style="line-height:2;">（利益包括：提高销售收入和利润、减少坏账损失、降低成本、提高资金周转率、减少对外部融资的依赖；减轻管理人员工作强度、提高工作效率、提升管理价值，等等。）</span> </p><p style="text-indent:2em;">	<br /></p>', 9, '', '', '', '0', 0, 0, 1, '0000-00-00 00:00:00'),
(5, '手机11111', '或犯人等特殊旅客，只有在符合航空公司规定的条件下经航空公司预先同意并做出安排后方予载运。传染病患者、精神病患者或健康情况可能危及自身或影响其他旅客安全的旅客，航空公司不予承运。根据国家有关规定不能乘机的旅客，航空公司有权拒绝其乘机，已购客票按自愿退票处理。\r\n', 7, '', '', '', '1', 0, 0, 1, '0000-00-00 00:00:00'),
(6, '手机22222', '公司有权拒绝其乘机，已购客票按自愿退票处理。\r\n', 7, '', '', '', '2', 0, 0, 1, '0000-00-00 00:00:00'),
(7, '手机33333', '乘机前，旅客及其行李必须经过安全检查。无成人陪伴儿童、病残旅客、孕妇、盲人、聋人或犯人等特殊旅客，只有在符合航空公司规定的条件下经航空公司预先同意并做出安排后方予载运。传染病患者、精神病患者或健康情况可能危及自身或影响其他旅客安全的旅客，航空公司不予承运。根据国家有关规定不能乘机的旅客，航空公司有权拒绝其乘机，已购客票按自愿退票处理。\r\n', 7, '', '', '', '3', 0, 0, 1, '0000-00-00 00:00:00'),
(8, '手机44444', '伴儿童、病残旅客、孕妇、盲人、聋人或犯人等特殊旅客，只有在符合航空公司规定的条件下经航空公司预先同意并做出安排后方予载运。传染病患者、精神病患者或健康情况可能危及自身或影响其他旅客安全的旅客，航空公司不予承运。根据国家有关规定不能乘机的旅客，航空公司有权拒绝其乘机，已购客票按自愿退票处理。\r\n', 7, '', '', '', '4', 0, 0, 1, '0000-00-00 00:00:00'),
(9, '手机55555', '管制刀具：指1983年经国务院批准由公安部颁发实施的《对部分刀具实行管制的暂行规定》中所列出的刀具，包括匕首、三棱刀（包括机械加工用的三棱刮 刀）、带有自锁装置的刀具和形似匕首但长度超过匕首的单刃刀、双刃刀以及其他类似的单单刃，双刃、三棱尖刀等。少数民族由于生活习惯需要佩戴、使用的藏 刀、腰刀、靴刀等属于管制刀具，只准在民族自治地方销售、使用。\r\n\r\n（四）易燃、易爆物品，包括：氢气、氧气、丁烷等瓶装压缩气体、液 化气体；黄磷、白磷、硝化纤维（含胶片）、油纸及其制品等自燃物品；金属钾、钠、锂、碳化钙（电石）、镁铝粉等遇水燃烧物品；汽油、煤油、柴油、苯、乙醇 （酒精）、\r\n', 8, '', '', '', '5', 0, 0, 1, '0000-00-00 00:00:00'),
(10, '电子往来账款管理系统', '电子往来账款管理系统是由典信公司独立开发的管理应用系统，具有自主知识产权。本系统主要侧重于企业往来及相关业务，包括往来、授信、信用管理等业务，系统以其为主要管理对象和业务对象，应用全新的思路进行设计和开发，突破了传统管理软件的瓶颈. 电子往来账款管理系统是由典信公司独立开发的管理应用系统，具有自主知识产权。本系统主要侧重于企业往来及相关业务，包括往来、授信、信用管理等业务，系统以其为主要管理对象和业务对象，应用全新的思路进行设计和开发，突破了传统管理软件的瓶颈. 电子往来账款管理系统是由典信公司独立开发的管理应用系统，具有自主知识产权。本系统主要侧重于企业往来及相关业务，包括往来、授信、信用管理等业务，系统以其为主要管理对象和业务对象，应用全新的思路进行设计和开发，突破了传统管理软件的瓶颈.', 18, '', '', '', './Public/Images/517e777f55578.jpg', 0, 0, 1, '0000-00-00 00:00:00'),
(11, '电子往来账款', '电子往来账款管理系统电子往来账款管理系统电子往来账款管理系统电子往来账款管理系统电子往来账款管理系统电子往来账款管理系统电子往来账款管理系统电子往来账款管理系统', 18, '', '', '', './Public/Images/0103040.jpg', 0, 0, 1, '0000-00-00 00:00:00'),
(12, '公司的产品系列', '乘机前，旅客及其行李必须经过安全检查。无成人陪伴儿童、病残旅客、孕妇、盲人、聋人或犯人等特殊旅客，只有在符合航空公司规定的条件下经航空公司预先同意并做出安排后方予载运。传染病患者、精神病患者或健康情况可能危及自身或影响其他旅客安全的旅客，航空公司不予承运。根据国家有关规定不能乘机的旅客，航空公司有权拒绝其乘机，已购客票按自愿退票处理。\r\n', 18, '', '', '', './Public/Images/new_show.jpg', 0, 0, 1, '0000-00-00 00:00:00'),
(15, 'PHP小组的文章2', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; KindEditor 是一套开源的在线HTML编辑器，主要用于让用户在网站上获得所见即所得编辑效果，开发人员可以用 KindEditor \n把传统的多行文本输入框(textarea)替换为可视化的富文本输入框。 KindEditor 使用 JavaScript 编写，可以无缝地与 \nJava、.NET、PHP、ASP 等程序集成，比较适合在 CMS、商城、论坛、博客、Wiki、电子邮件等互联网应用上使用。', 21, '大秘密', '文章', '马伊咪', '0', 0, 0, 1, '0000-00-00 00:00:00'),
(17, 'java学习基础', 'java学习基础java学习基础java学习基础java学习基础java学习基础java学习基础java学习基础java学习基础java学习基础java学习基础java学习基础java学习基础', 22, 'java学习基础java学习基础', 'java学习基础', 'java学习基础', './Public/Images/517e76eede991.jpg', 0, 0, 1, '2013-04-13 16:44:35'),
(19, '312312', 'gadasdasdakdasdasdasdadsa', 19, '', '', '', './Public/Images/517e81e21756b.jpg', 0, 0, 1, '2013-04-29 22:21:22');

-- --------------------------------------------------------

--
-- 表的结构 `fy_class`
--

CREATE TABLE IF NOT EXISTS `fy_class` (
  `class_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) NOT NULL DEFAULT '',
  `class_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `class_path` varchar(200) NOT NULL DEFAULT '0',
  `picture_id` int(10) unsigned NOT NULL,
  `class_order` int(10) unsigned NOT NULL DEFAULT '0',
  `class_module` varchar(200) NOT NULL DEFAULT '',
  `class_using` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='分类表' AUTO_INCREMENT=23 ;

--
-- 转存表中的数据 `fy_class`
--

INSERT INTO `fy_class` (`class_id`, `class_name`, `class_pid`, `class_path`, `picture_id`, `class_order`, `class_module`, `class_using`, `create_time`) VALUES
(1, '首页', 0, '0', 19, 0, 'Index', 1, '0000-00-00 00:00:00'),
(2, '关于我们', 0, '0', 5, 0, 'About', 1, '0000-00-00 00:00:00'),
(3, '公司介绍', 2, '0-2', 0, 0, '', 1, '0000-00-00 00:00:00'),
(4, '企业文化', 2, '0-2', 0, 0, '', 1, '0000-00-00 00:00:00'),
(5, '联系我们', 2, '0-2', 0, 0, '', 1, '0000-00-00 00:00:00'),
(6, '产品分类', 0, '0', 2, 0, 'Product', 0, '0000-00-00 00:00:00'),
(7, '电子', 6, '0-6', 0, 0, '', 0, '0000-00-00 00:00:00'),
(8, '家具', 6, '0-6', 0, 0, '', 0, '0000-00-00 00:00:00'),
(9, '书籍', 6, '0-6', 0, 0, '', 0, '0000-00-00 00:00:00'),
(10, '智能手机', 7, '0-6-7', 0, 0, '', 0, '0000-00-00 00:00:00'),
(11, '数码相机', 7, '0-6-7', 0, 0, '', 0, '0000-00-00 00:00:00'),
(12, '平板电脑', 7, '0-6-7', 0, 0, '', 0, '0000-00-00 00:00:00'),
(13, '洗衣机', 8, '0-6-8', 0, 0, '', 0, '0000-00-00 00:00:00'),
(14, '电冰箱', 8, '0-6-8', 0, 0, '', 0, '0000-00-00 00:00:00'),
(15, 'Iphone 4S', 10, '0-6-7-10', 0, 0, '', 0, '0000-00-00 00:00:00'),
(16, '产品·服务', 0, '0', 1, 0, 'Service', 1, '0000-00-00 00:00:00'),
(18, '公司产品', 16, '0-16', 0, 0, '', 1, '0000-00-00 00:00:00'),
(19, '服务支持', 16, '0-16', 0, 0, '', 1, '0000-00-00 00:00:00'),
(20, '公司动态', 0, '0', 21, 0, 'News', 1, '0000-00-00 00:00:00'),
(21, 'PHP小组', 20, '0-20', 0, 0, '', 1, '0000-00-00 00:00:00'),
(22, 'JAVA小组', 20, '0-20', 0, 0, '', 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `fy_config`
--

CREATE TABLE IF NOT EXISTS `fy_config` (
  `config_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `config_name` varchar(200) NOT NULL,
  `config_value` varchar(500) NOT NULL,
  `config_using` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `fy_config`
--

INSERT INTO `fy_config` (`config_id`, `config_name`, `config_value`, `config_using`) VALUES
(1, 'web_logo', './Public/Images/logo.png', 1),
(2, 'web_name', '深圳市典信科技有限公司', 1),
(3, 'record_no', '粤ICP备:11086626号-2 ', 1),
(4, 'conpany_address', '深圳市宝安区2区龙井二路62号6楼 ', 1),
(5, 'conpany_email', 'jeffyli@basicredit.com', 1),
(6, 'ebs_info', '<script src="http://www.ebs.gov.cn/Validate/IconProcess.aspx?domainid=3B7FF64E-F875-4EE4-9F34-998E6500A901&show=pic&width=140&height=50" type="text/javascript"></script>', 0),
(7, 'conpany_weibo', 'http://weibo.com', 0);

-- --------------------------------------------------------

--
-- 表的结构 `fy_picture`
--

CREATE TABLE IF NOT EXISTS `fy_picture` (
  `picture_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `picture_name` varchar(255) NOT NULL DEFAULT '',
  `picture_thumb` varchar(255) NOT NULL DEFAULT '',
  `picture_path` varchar(1000) NOT NULL DEFAULT '',
  `picture_purpose` int(11) NOT NULL,
  `picture_using` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`picture_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='图片表' AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `fy_picture`
--

INSERT INTO `fy_picture` (`picture_id`, `picture_name`, `picture_thumb`, `picture_path`, `picture_purpose`, `picture_using`, `create_time`) VALUES
(1, '', './Public/Images/1.jpg', './Public/Images/1.jpg', 1, 1, '0000-00-00 00:00:00'),
(2, '', './Public/Images/2.jpg', './Public/Images/2.jpg', 1, 1, '0000-00-00 00:00:00'),
(3, '', './Public/Images/3.jpg', './Public/Images/3.jpg', 1, 1, '0000-00-00 00:00:00'),
(4, '', './Public/Images/4.jpg', './Public/Images/4.jpg', 1, 1, '0000-00-00 00:00:00'),
(5, '', './Public/Images/5.jpg', './Public/Images/5.jpg', 1, 1, '0000-00-00 00:00:00'),
(6, '', './Public/Images/5.jpg', './Public/Images/5.jpg', 2, 1, '0000-00-00 00:00:00'),
(7, '', './Public/Images/3.jpg', './Public/Images/3.jpg', 5, 1, '0000-00-00 00:00:00'),
(8, '', './Public/Images/2.jpg', './Public/Images/2.jpg', 6, 1, '0000-00-00 00:00:00'),
(9, '', './Public/Images/4.jpg', './Public/Images/4.jpg', 16, 1, '0000-00-00 00:00:00'),
(10, '5172acc8f3276.jpg', './Public/Uploads/_thumb5172acc8f3276.jpg', './Public/Uploads/5172acc8f3276.jpg', 0, 1, '2013-04-20 22:57:13'),
(11, '5172ae41f3b2e.jpg', './Public/Uploads/thumb_5172ae41f3b2e.jpg', './Public/Uploads/5172ae41f3b2e.jpg', 0, 1, '2013-04-20 23:03:30'),
(12, '5172aec3ef738.jpg', './Public/Uploads/thumb_5172aec3ef738.jpg', './Public/Uploads/5172aec3ef738.jpg', 0, 1, '2013-04-20 23:05:40'),
(13, '5172aef173db9.jpg', './Public/Uploads/thumb_5172aef173db9.jpg', './Public/Uploads/5172aef173db9.jpg', 0, 1, '2013-04-20 23:06:25'),
(14, '5172aef2d4096.jpg', './Public/Uploads/thumb_5172aef2d4096.jpg', './Public/Uploads/5172aef2d4096.jpg', 0, 1, '2013-04-20 23:06:27'),
(15, '5172aef3e2314.jpg', './Public/Uploads/thumb_5172aef3e2314.jpg', './Public/Uploads/5172aef3e2314.jpg', 0, 1, '2013-04-20 23:06:28'),
(16, '5172aef50ff13.jpg', './Public/Uploads/thumb_5172aef50ff13.jpg', './Public/Uploads/5172aef50ff13.jpg', 0, 1, '2013-04-20 23:06:29'),
(17, '5172aef95becd.jpg', './Public/Uploads/thumb_5172aef95becd.jpg', './Public/Uploads/5172aef95becd.jpg', 0, 1, '2013-04-20 23:06:33'),
(18, '5172af5b7644a.jpg', './Public/Uploads/thumb_5172af5b7644a.jpg', './Public/Uploads/5172af5b7644a.jpg', 0, 1, '2013-04-20 23:08:11'),
(19, '5172af971c7c3.jpg', './Public/Uploads/thumb_5172af971c7c3.jpg', './Public/Uploads/5172af971c7c3.jpg', 0, 1, '2013-04-20 23:09:11'),
(20, '5172b0c647283.jpg', './Public/Uploads/thumb_5172b0c647283.jpg', './Public/Uploads/5172b0c647283.jpg', 0, 1, '2013-04-20 23:14:14'),
(21, '5172b10332694.jpg', './Public/Uploads/thumb_5172b10332694.jpg', './Public/Uploads/5172b10332694.jpg', 0, 1, '2013-04-20 23:15:15');
